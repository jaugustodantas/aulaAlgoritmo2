
        print("Senha forte criada com sucesso")
        break
    else:
        print("A senha deve ter no mínimo 1 letra maiuscula e 1 número")