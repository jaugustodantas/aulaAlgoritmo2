numero = int(input("Digite um numero interio: "))
if numero >0:
    print(f'O número {numero} é possitivo')
elif numero < 0:
    print(f'O número {numero} é negativo')
else:
    print("Número = 0 ")