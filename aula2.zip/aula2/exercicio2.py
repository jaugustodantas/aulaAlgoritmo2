nome = input("Qual o seu nome? ") #entrada do nome do usuário
print(f"Bem vindo de volta, {nome}") # faz a saudação com o nome do usuário =|